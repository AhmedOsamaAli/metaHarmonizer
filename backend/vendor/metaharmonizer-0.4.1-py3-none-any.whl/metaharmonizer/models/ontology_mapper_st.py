import pandas as pd
import numpy as np
import faiss
import torch
from transformers import AutoTokenizer
import metaharmonizer.models.ontology_models as otm


class OntoMapST(otm.OntoModelsBase):
    """
    A class to map ontologies using sentence transformers.

    Attributes:
        method (str): The method to use for the model.
        query (list[str]): The list of query strings.
        corpus (list[str]): The list of corpus strings.
        top_k (int): The number of top results to consider.
        from_tokenizer (bool): Whether to use a tokenizer.
        _query_embeddings (torch.Tensor or None): Embeddings for the queries.
        _corpus_embeddings (torch.Tensor or None): Embeddings for the corpus.
        _model (AutoModel or SentenceTransformer or None): The model instance.
        _tokenizer (AutoTokenizer or None): The tokenizer instance.
        logger (CustomLogger): Logger instance.
    """

    def __init__(self,
                 method: str,
                 category: str,
                 query: list[str],
                 corpus: list[str],
                 om_strategy: str = 'st',
                 top_k: int = 5,
                 from_tokenizer: bool = False,
                 ontology_source: str = 'ncit',
                 table_suffix: str = "") -> None:
        """
        Initializes the OntoMapST class.

        Args:
            method (str): The method to use for the model.
            top_k (int): The number of top results to consider.
            query (list[str]): The list of query strings.
            corpus (list[str]): The list of corpus strings.
            from_tokenizer (bool, optional): Whether to use a tokenizer. Defaults to False.
            ontology_source (str, optional): Ontology source. Defaults to 'ncit'.
        """
        super().__init__(method, category, om_strategy, top_k, query, corpus,
                         ontology_source=ontology_source,
                         table_suffix=table_suffix)

        self.from_tokenizer = from_tokenizer
        self._query_embeddings = None
        self._corpus_embeddings = None
        self._model = None
        self._tokenizer = None
        self.logger.info("Initialized OntoMap Sentence Transformer module")

    @property
    def tokenizer(self):
        """
        Gets the tokenizer instance.

        Returns:
            AutoTokenizer or None: The tokenizer instance if from_tokenizer is True, otherwise None.
        """
        if self.from_tokenizer:
            self._tokenizer = AutoTokenizer.from_pretrained(
                self.method_model_dict[self.method])
            return self._tokenizer
        else:
            return None

    @property
    def model(self):
        if self._model is None:
            from metaharmonizer.utils.model_loader import get_embedding_model_cached
            self._model = get_embedding_model_cached(self.method)
        return self._model

    @property
    def query_embeddings(self):
        """
        Gets the embeddings for the queries.

        Returns:
            torch.Tensor: The query embeddings.
        """
        if self._query_embeddings is None:
            self._query_embeddings = self.create_embeddings(self.query)
        return self._query_embeddings

    @property
    def corpus_embeddings(self):
        """
        Gets the embeddings for the corpus.

        Returns:
            torch.Tensor: The corpus embeddings.
        """
        if self._corpus_embeddings is None:
            idx = faiss.read_index(self.vector_store.index_path)
            vecs = np.vstack([idx.reconstruct(i) for i in range(idx.ntotal)])
            self._corpus_embeddings = vecs
        return self._corpus_embeddings

    def create_embeddings(self,
                          query_list: list[str],
                          convert_to_tensor: bool = True):
        """
        Creates embeddings for the sentence transformer model.

        Args:
            query_list (list[str]): List of query strings.
            convert_to_tensor (bool, optional): Whether to convert the output embeddings to tensor. Defaults to True.

        Returns:
            numpy.ndarray or torch.Tensor: The output embeddings.
        """
        return self.model.encode(
            query_list,
            convert_to_tensor=convert_to_tensor,
            device='cuda' if torch.cuda.is_available() else 'cpu')

    def get_match_results(self,
                          ground_truth_map: dict[str, str] = None,
                          top_k: int = 5,
                          test_or_prod: str = 'test') -> pd.DataFrame:
        if test_or_prod == 'test' and ground_truth_map is None:
            raise ValueError("ground_truth_map should be provided for test mode")

        idx = self.vector_store.index

        q_embs = self.create_embeddings(self.query, convert_to_tensor=False)
        q_mat = np.array(q_embs, dtype="float32")

        norms = np.linalg.norm(q_mat, axis=1, keepdims=True)
        q_norm = q_mat / (norms + 1e-12)

        D, I = idx.search(q_norm, top_k)

        return self._build_result_rows(I, D, ground_truth_map, test_or_prod)
